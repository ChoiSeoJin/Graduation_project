import React from 'react';
import '../css/Body.css';

const Upload_Script = () => {
	return(
		<div className="body_main">
            <div className="body_head">
            Upload_Script
            </div>

            
        </div>
	);
};

export default Upload_Script;