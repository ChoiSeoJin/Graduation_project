import React from 'react';
import '../css/Body.css';

const JobCreate = () => {
	return(
		<div className="body_main">
            <div className="body_head">
            Job Create
            </div>

            
        </div>
	);
};

export default JobCreate;